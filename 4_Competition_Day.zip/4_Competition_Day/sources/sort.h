#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Cars {
	int id;			//Car ID
	int n_streets;  //The number of streets
	char **path;    //The path for this car
	int curr_street;  //The index of the current street
	double score;     //Property to sort the cars
} car_t;

typedef struct Streets {
	int id; 		//Street ID
	char name[31];	//Street Name
	int time;		//Time to arrive in the end of this street
	int start;		//Intersection in the beginning of the street
	int end;		//Intersection in the end of the street
	double score;	//Property to sort the Libraries
} street_t;

typedef struct Intersections {
	int id; 		//Intersection ID
	int *time; 		//Green Light Time
	int *street_id; //Street ID (We can access the variables)
	int n_streets;  //The number of streets to Schedule
	double score;	//Property to sort the Libraries
} intersection_t;

void mergesort_streets(street_t *v, int ini, int fim);