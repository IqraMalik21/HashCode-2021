DATASET="Dataset"

make 
#make run < $DATASET/b.txt

make run < $DATASET/a.txt &> a.out
make run < $DATASET/b.txt &> b.out
make run < $DATASET/c.txt &> c.out
make run < $DATASET/d.txt &> d.out
make run < $DATASET/e.txt &> e.out
make run < $DATASET/f.txt &> f.out

make clean
