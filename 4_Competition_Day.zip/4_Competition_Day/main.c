#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sort.h"

/* This function will generate the output file format
** Parameters:
**  int D; //an integer D (1 ≤ D ≤ 10 4) - the duration of the simulation, in seconds,
**  int I; //an integer I (2 ≤ I ≤ 10 5) - the number of intersections (with IDs from 0 to I -1 ),
**  int S; //an integer S (2 ≤ S ≤ 10 5) - the number of streets,
**  int V; //an integer V (1 ≤ V ≤ 10 3) - the number of cars,
**  int F; //an integer F (1 ≤ F ≤ 10 3) - the bonus points for each car that reaches its destination before time D.
**  street_t * streets; 
**  car_t * cars;
*/
void generates_output_file(int D, int I, int S, int V, int F, street_t *streets){
	int A = 0; //number of intersections for which you specify the schedule.
	//the first l ine containing a single i nteger i (0 ≤ i < I ) – the ID of the intersection,
	//the second line containing a single integer E i ( 0 < E i ) – the number of incoming streets (of the i ntersection i ) covered by this schedule,
	//E i l ines describing the order and duration of green l ights. Each of those lines must contain (separated by a single space):
		//the street name,
		//an i nteger T (1 ≤ T ≤ D ) – for how l ong each street will have a green light.

	int i, j;

	mergesort_streets(streets, 0, S-1);

	//Define A value
	int sum; //The sum of Time
	int l = 0; //Iterates the Streets (Index)
	for (sum=0; sum<D; sum += streets[l++].time){
		if (A < I) A++;
	}
	//printf("A=%d, D=%d, sum=%d\n", A, D, sum);

	intersection_t * intersections = (intersection_t*)malloc(A*sizeof(intersection_t));

	for (i=0; i<A; i++) {
		intersections[i].id = i;
		intersections[i].score = 0;
		int n_streets = 0;  //The number of streets to Schedule
		
		for (j=0; j<S; j++){
			if (streets[j].end == intersections[i].id) n_streets++;
		}
		intersections[i].n_streets = n_streets;

		//printf("n_streets: %d\n", intersections[i].n_streets);

		intersections[i].street_id = (int*)malloc(intersections[i].n_streets * sizeof(int));
		intersections[i].time = (int*)malloc(intersections[i].n_streets * sizeof(int));
		int ind = 0;
		for (j=0; j<S; j++){
			if (streets[j].end == intersections[i].id) {
				int time = 2; //We need to set the time automatically
				if (ind < intersections[i].n_streets) {
					intersections[i].street_id[ind] = j; //streets[j].id;
					intersections[i].time[ind] = time;
					ind++;
				}
			}
		}
	}

	//Error: The schedule of intersection 0 refers to street rue-de-moscou,
	//but that street does not enter this intersection, so it cannot be part of the intersection schedule.

	//Output:
	printf("%d\n", A);
	for (i=0; i<A; i++){
		printf("%d\n", intersections[i].id);
		printf("%d\n", intersections[i].n_streets);

		int street_index = 0;
		int time_index = 0;

		for (j=0; j<intersections[i].n_streets; j++) {
			printf("%s %d\n", streets[ intersections[i].street_id[street_index] ].name, intersections[i].time[time_index]);
			street_index++;
			time_index++;
		}
	}

	/*Example:
		A  -> Number of intersections to Schedule
			id[i] -> Id of each intersection
			n_streets -> number of streets to set Green Light
				street[j] time[j] -> Street Name and the Time Duration for Green Light
	*/
	
	free(intersections);
}

int main () {
	//Variables
	int D; //an integer D (1 ≤ D ≤ 10 4) - the duration of the simulation, in seconds,
	int I; //an integer I (2 ≤ I ≤ 10 5) - the number of intersections (with IDs from 0 to I -1 ),
	int S; //an integer S (2 ≤ S ≤ 10 5) - the number of streets,
	int V; //an integer V (1 ≤ V ≤ 10 3) - the number of cars,
	int F; //an integer F (1 ≤ F ≤ 10 3) - the bonus points for each car that reaches its destination before time D.

	//Read Input File
	scanf("%d %d %d %d %d", &D, &I, &S, &V, &F);
	//printf("%d %d %d %d %d\n", D, I, S, V, F);

	int i, j;
	street_t *streets = (street_t*)malloc(S*sizeof(street_t));
	for(i=0; i<S; i++){ //The next S lines contain descriptions of streets. Each line contains:
		int B, E; //two integers B and E (0 ≤ B < I , 0 ≤ E < I ) - the intersections at the start and the end of the street, respectively,
		char street_name[31]; //the street name (a string consisting of between 3 and 30 lowercase ASCII characters a -z and the character - ),
		int L; //an integer L (1 ≤ L ≤ D ) - the time it takes a car to get from the beginning to the end of that street.
		scanf("%d %d %s %d ", &B, &E, street_name, &L);
		//printf("%d %d %s %d\n", B, E, street_name, L);

		streets[i].id    = i;
		strcpy(streets[i].name, street_name);
		streets[i].time  = L;
		streets[i].start = B;
		streets[i].end   = E;
		streets[i].score = streets[i].time;
		//printf("%d %d %s %d %d\n", streets[i].start, streets[i].end, streets[i].name, streets[i].time, streets[i].id);
	}

	/*car_t *cars = (car_t*)malloc(V*sizeof(car_t));
	for (i=0; i< V; i++){ //The next V lines describe the paths of each car. Each line contains:
		int P; //an integer P (2 ≤ P ≤ 10 3) - the number of streets that the car wants to travel,
		//char **path; /*followed by P names of the streets: The car stas at the end of the first street (i.e. it waits for 
			//the green light to move to the next street) and follows the path until the end of the last street.
			//The path of a car is always valid, i.e. the streets will be connected by intersections.
		scanf("%d", &P);
		//printf("%d ", P);

		cars[i].id = i;
		cars[i].n_streets = P;
		//printf("%d ", cars[i].n_streets);

		cars[i].path = (char**)malloc(P*sizeof(char*));
		for (j=0; j<P; j++){
			cars[i].path[i] = (char*)malloc(31*sizeof(char));
			scanf("%s ", cars[i].path[i]);
			//printf("%s ", cars[i].path[i]);
		}

		cars[i].curr_street = 0; //Starts in the index 0 of the path array
		cars[i].score = 0.0;

		//printf("\n");
	}*/


	//Solution
	generates_output_file(D, I, S, V, F, streets);


	//Deallocate Memory
	free(streets);

	/*for (i=0; i<V; i++){
		free(cars[i].path);
	}
	free(cars);*/
	
	return 0;
}